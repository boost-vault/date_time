
#ifndef __DATE_TIME_COUNTDOWN_TIMER_HPP__
#define __DATE_TIME_COUNTDOWN_TIMER_HPP__

/* Copyright (c) 2005 CrystalClear Software, Inc.
 * Use, modification and distribution is subject to the 
 * Boost Software License, Version 1.0. (See accompanying
 * file LICENSE-1.0 or http://www.boost.org/LICENSE-1.0)
 * Author: Jeff Garland
 * $Date: 2005/07/30 05:50:48 $
 */



//todo behaviors related to wrap around (eg: nasa mission timers)
template<class time_duration_type, class impl_type>             
class countdown_timer_interface
{
 public:
  countdown_timer_interface(time_duration_type td) :
    m_impl(td)
  {}  

  void start() 
  { 
    m_impl.start();
  } 
  void restart() 
  { 
    m_impl.start();
  } 
  
  time_duration_type remaining() const
  {
    return m_impl.remaining();
  }
  void pause()                  
  { 
    m_impl.pause();
  }

  void resume()
  { 
    m_impl.resume();
  }
  void reset()
  {
    m_impl.reset();
  }

 private:
  
  impl_type m_impl;

};


//todo behaviors related to wrap around (eg: nasa mission timers)
template<class clock_type, 
         class time_duration_type, 
         class time_type>             
class countdown_timer_impl
{
 public:
  countdown_timer_impl(time_duration_type td) :
    m_total_duration(td),
    m_remaining(td),
    m_start_time(not_a_date_time)
  {}  

  void start() 
  { 
    if (m_start_time.is_not_a_date_time()) {
      m_start_time = clock_type::local_time(); 
    }
  } 
  void restart() 
  { 
    reset();
    start();
  } 
  
  time_duration_type remaining() const
  {
    if (m_start_time.is_not_a_date_time()) {
      return m_remaining;
    }
    time_type current = clock_type::local_time();
    return (m_remaining - (current - m_start_time));

  }
  void pause()                  
  { 
    time_type current = clock_type::local_time();
    m_remaining -= (current - m_start_time);
    //not_a_date_time signals a not-running state
    m_start_time = time_type(not_a_date_time); 
  }

  void resume()
  { 
    if (m_start_time.is_not_a_date_time()) {
      m_start_time = clock_type::local_time();
    }
  }
  void reset()
  {
    m_remaining = m_total_duration;
    if (!m_start_time.is_not_a_date_time()) {
      m_start_time = clock_type::local_time();
    }
  }

 private:
  
  time_duration_type m_total_duration;
  time_duration_type m_remaining;
  time_type m_start_time;

};




#endif
