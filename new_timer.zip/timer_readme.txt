
This is some experimental code to provide timer interfaces.  The prototypes include code to replace the current Boost.Timer as well as providing countdown timers which are useful in many apps.

