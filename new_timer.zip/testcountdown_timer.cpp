

#include "boost/date_time/posix_time/posix_time.hpp"
#include "countdown_timer.hpp"


using namespace boost::posix_time;

//typedef countdown_timer<second_clock> countdown_second_timer;

typedef countdown_timer_impl<second_clock, time_duration, ptime> second_impl;

typedef countdown_timer_interface<time_duration, second_impl> countdown_second_timer;


typedef countdown_timer_impl<microsec_clock, time_duration, ptime> micro_impl;

typedef countdown_timer_interface<time_duration, micro_impl> countdown_micro_timer;

int
main()
{
  
  countdown_second_timer st(seconds(5));
  
  std::cout << st.remaining() << std::endl;
  st.start();
  sleep(1);
  std::cout << st.remaining() << std::endl;
  sleep(1);
  st.pause();
  std::cout << st.remaining() << std::endl;
  sleep(1);
  std::cout << st.remaining() << std::endl;
  st.resume();
  sleep(1);
  std::cout << st.remaining() << std::endl;
  sleep(1);
  std::cout << st.remaining() << std::endl;
  sleep(1);
  std::cout << st.remaining() << std::endl;
  sleep(1);
  std::cout << st.remaining() << std::endl;
  st.reset();
  std::cout << st.remaining() << std::endl;
  sleep(1);
  std::cout << st.remaining() << std::endl;
  
  countdown_micro_timer mt(seconds(5));
  
  std::cout << mt.remaining() << std::endl;
  mt.start();
  sleep(1);
  std::cout << mt.remaining() << std::endl;
  sleep(1);
  mt.pause();
  std::cout << mt.remaining() << std::endl;
  sleep(1);
  std::cout << mt.remaining() << std::endl;
  mt.resume();
  sleep(1);
  std::cout << mt.remaining() << std::endl;
  sleep(1);
  std::cout << mt.remaining() << std::endl;
  sleep(1);
  std::cout << mt.remaining() << std::endl;
  sleep(1);
  std::cout << mt.remaining() << std::endl;
  mt.reset();
  std::cout << mt.remaining() << std::endl;
  sleep(1);
  std::cout << mt.remaining() << std::endl;


  return 0;
}
