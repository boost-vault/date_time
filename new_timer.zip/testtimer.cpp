

#include "boost/date_time/posix_time/posix_time.hpp"
#include "timer.hpp"


typedef timer<second_clock> second_timer;

typedef timer<microsec_clock> micro_timer;

int
main()
{
  
  second_timer st;
  std::cout << st.elapsed() << std::endl;
  sleep(1);
  std::cout << st.elapsed() << std::endl;
  sleep(1);
  st.pause();
  std::cout << st.elapsed() << std::endl;
  sleep(1);
  std::cout << st.elapsed() << std::endl;
  st.resume();
  sleep(1);
  std::cout << st.elapsed() << std::endl;
  sleep(1);
  std::cout << st.elapsed() << std::endl;
  sleep(1);
  // 5 seconds elapsed here
  std::cout << st.elapsed() << std::endl;
  st.reset();
  sleep(1);
  std::cout << st.elapsed() << std::endl;

  micro_timer mt;
  std::cout << mt.elapsed() << std::endl;
  sleep(1);
  std::cout << mt.elapsed() << std::endl;
  sleep(1);
  mt.pause();
  std::cout << mt.elapsed() << std::endl;
  sleep(1);
  std::cout << mt.elapsed() << std::endl;
  mt.resume();
  sleep(1);
  std::cout << mt.elapsed() << std::endl;
  sleep(1);
  std::cout << mt.elapsed() << std::endl;
  sleep(1);
  // 5 seconds elapsed here
  std::cout << mt.elapsed() << std::endl;
  mt.reset();
  sleep(1);
  std::cout << mt.elapsed() << std::endl;

  return 0;
}
