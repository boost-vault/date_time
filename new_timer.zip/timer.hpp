#ifndef __POSIX_TIME_TIMER_HPP__
#define __POSIX_TIME_TIMER_HPP__

/* Copyright (c) 2005 CrystalClear Software, Inc.
 * Use, modification and distribution is subject to the 
 * Boost Software License, Version 1.0. (See accompanying
 * file LICENSE-1.0 or http://www.boost.org/LICENSE-1.0)
 * Author: Jeff Garland
 * $Date: 2005/07/30 05:50:48 $
 */


using namespace boost::posix_time; //todo remove

//not compiled, just a detailed sketch
template<class clock_type>             
class timer {
 public:

  enum START_OPTION {AUTO_START, MANUAL_START};

  timer(time_duration initial_duration = time_duration(0,0,0),
        START_OPTION start_op = AUTO_START) : 
    m_start_time(ptime(not_a_date_time)),
    m_elapsed(initial_duration)
  {
    if (start_op == AUTO_START) {
      start();
    }
  } 
  void start() 
  { 
    if (m_start_time.is_not_a_date_time()) {
      m_start_time = clock_type::local_time(); 
    }
  } 
  void restart() 
  { 
    reset();
    start();
  } 
  time_duration elapsed() const                  
  { 
    if (m_start_time != ptime(not_a_date_time)) {
      boost::posix_time::ptime current = clock_type::local_time();
      m_elapsed += (current - m_start_time);
      m_start_time = current;
    }
    return m_elapsed;
  }
  void pause()                  
  { 
    boost::posix_time::ptime current = clock_type::local_time();
    m_elapsed += (current - m_start_time);
    //not_a_date_time signals a not-running state
    m_start_time = ptime(not_a_date_time); 
  }
  void resume()
  { 
    if (m_start_time.is_not_a_date_time()) {
      m_start_time = clock_type::local_time();
    }
  }
  void reset()
  {
    m_elapsed = time_duration(0,0,0); 
    if (!m_start_time.is_not_a_date_time()) {
      m_start_time = clock_type::local_time();
    }
  }
 private:
  mutable boost::posix_time::ptime m_start_time;
  mutable boost::posix_time::time_duration m_elapsed;
 }; // timer

#endif
