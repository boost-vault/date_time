#ifndef BOOST_TIMER_HPP
#define BOOST_TIMER_HPP

// Copyright (c) 2005 CrystalClear Software, Inc.
// (C) Copyright Vaucher Philippe 2006
// Use, modification and distribution is subject to the 
// Boost Software License, Version 1.0. (See accompanying
// file LICENSE-1.0 or http://www.boost.org/LICENSE-1.0)
// Original draft: Jeff Garland 2005
// Extensions: Vaucher Philippe 2006


// -------------------------- Includes --------------------------

// Boost headers
#include <boost/date_time/posix_time/posix_time.hpp>


// -------------------------- Code --------------------------

//  To speed up compilation a bit on msvc
#if (defined _MSC_VER) && (_MSC_VER >= 1200)
    #pragma once
#endif

namespace boost
{

// Clock is a date_time type used to get the current time
// Time is a date_time type used to represent that time
template<class Clock, class Time = boost::posix_time::ptime>
class timer
{

  public:

    typedef Clock clock_type;
    typedef Time time_type;
    typedef typename time_type::time_duration_type time_duration_type;

    enum start_options { auto_start = 1, manual_start };

    explicit timer(time_duration_type initial_duration = time_duration_type(0, 0, 0), start_options start_op = auto_start)
    : m_start(boost::date_time::not_a_date_time), m_elapsed(initial_duration)
    {
        if(start_op == auto_start)
            start();
    }

    void start() 
    {
	    if(m_start.is_not_a_date_time())
		    m_start = clock_type::local_time();
    }

    void restart()
    {
        reset();
        start();
    }

    time_duration_type elapsed() const
    {
        if(!m_start.is_not_a_date_time())
        {
            time_type current(clock_type::local_time());
            m_elapsed += (current - m_start);
            m_start = current;
        }
        return m_elapsed;
    }

    void pause()
    {
        if(!m_start.is_not_a_date_time())
        {
            m_elapsed += (clock_type::local_time() - m_start);
            m_start = boost::date_time::not_a_date_time; 
        }
    }

    void resume()
    {
        if(m_start.is_not_a_date_time())
            m_start = clock_type::local_time();
    }

    void reset()
    {
        m_elapsed = time_duration_type(0,0,0);
        if(!m_start.is_not_a_date_time())
            m_start = clock_type::local_time();
    }


  private:

    mutable time_type m_start;
    mutable time_duration_type m_elapsed;

};

// Convenience typedefs
typedef boost::timer<boost::posix_time::second_clock>	second_timer;
typedef boost::timer<boost::posix_time::microsec_clock> microsec_timer;


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -------------------------- Additional Win32 timers --------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

#ifdef BOOST_WINDOWS

// -------------------------- Includes --------------------------

// Boost headers
#include <boost/throw_exception.hpp>

// Windows headers
#define WIN32_LEAN_AND_MEAN
#include <windows.h>


// -------------------------- QueryPerformanceCounter() timer --------------------------

namespace timer_detail
{
    class qpc_clock;
}

template <class Time>
class timer<boost::timer_detail::qpc_clock, Time>
{

  public:

    typedef Time time_type;
    typedef typename time_type::time_duration_type time_duration_type;

    enum start_options { auto_start = 1, manual_start };

    explicit timer(time_duration_type initial_duration = time_duration_type(0, 0, 0), start_options start_op = auto_start)
    : m_elapsed(initial_duration)
    {
        m_start.QuadPart = 0;
        if(!QueryPerformanceFrequency(&m_frequency))
            boost::throw_exception(std::runtime_error("qpc_timer: QueryPerformanceFrequency() indicated there's no high-resolution performance counter"));
        // Make it so we have the future results directly in milliseconds
        m_frequency.QuadPart /= 1000;
        if(start_op == auto_start)
            start();
    }

    void start() 
    {
        if(!m_start.QuadPart && !QueryPerformanceCounter(&m_start))
            boost::throw_exception(std::runtime_error("qpc_timer: QueryPerformanceCounter() failed"));
    }

    void restart()
    {
        reset();
        start();
    }

    time_duration_type elapsed() const
    {
        if(m_start.QuadPart)
        {
            LARGE_INTEGER current;
            if(!QueryPerformanceCounter(&current))
                boost::throw_exception(std::runtime_error("qpc: QueryPerformanceCounter() failed"));
            boost::uint64_t milliseconds = (current.QuadPart - m_start.QuadPart) / m_frequency.QuadPart;
            m_elapsed += boost::posix_time::milliseconds(milliseconds);
            m_start = current;
        }
        return m_elapsed;
    }

    void pause()
    {
        if(m_start.QuadPart)
        {
            LARGE_INTEGER current;
            if(!QueryPerformanceCounter(&current))
                boost::throw_exception(std::runtime_error("precise_timer: QueryPerformanceCounter() failed"));
            boost::uint64_t milliseconds = (current.QuadPart - m_start.QuadPart) / m_frequency.QuadPart;
            m_elapsed += boost::posix_time::nanoseconds(milliseconds);
            m_start.QuadPart = 0; 
        }
    }

    void resume()
    {
        if(!m_start.QuadPart)
        {
            if(!QueryPerformanceCounter(&m_start))
                boost::throw_exception(std::runtime_error("precise_timer: QueryPerformanceCounter() failed"));
        }
    }

    void reset()
    {
        m_elapsed = time_duration_type(0,0,0);
        if(m_start.QuadPart)
        {
            if(!QueryPerformanceCounter(&m_start))
                boost::throw_exception(std::runtime_error("precise_timer: QueryPerformanceCounter() failed"));
        }
    }


  private:

    LARGE_INTEGER m_frequency;
    mutable LARGE_INTEGER m_start;
    mutable time_duration_type m_elapsed;

};

// Convenience typedef
typedef boost::timer<boost::timer_detail::qpc_clock> qpc_timer;


// -------------------------- timeGetTime() timer --------------------------

#ifndef BOOST_TIMER_NO_LIBS_LINKED
    #pragma comment(lib, "winmm.lib")
#endif

namespace timer_detail
{
    class tgt_clock;
}

template <class Time>
class timer<boost::timer_detail::tgt_clock, Time>
{

  public:

    typedef Time time_type;
    typedef typename time_type::time_duration_type time_duration_type;

    enum start_options { auto_start = 1, manual_start };

    explicit timer(time_duration_type initial_duration = time_duration_type(0, 0, 0), start_options start_op = auto_start)
    : m_start(0), m_elapsed(initial_duration)
    {
        if(start_op == auto_start)
            start();
    }

    void start() 
    {
        if(!m_start)
            m_start = timeGetTime();
    }

    void restart()
    {
        reset();
        start();
    }

    time_duration_type elapsed() const
    {
        if(m_start)
        {
            boost::uint32_t current = timeGetTime();
            m_elapsed += boost::posix_time::milliseconds(current - m_start);
            m_start = current;
        }
        return m_elapsed;
    }

    void pause()
    {
        if(m_start)
        {
            boost::uint32_t current = timeGetTime();
            m_elapsed += boost::posix_time::milliseconds(current - m_start);
            m_start = 0; 
        }
    }

    void resume()
    {
        if(!m_start)
            m_start = timeGetTime();
    }

    void reset()
    {
        m_elapsed = time_duration_type(0,0,0);
        if(m_start)
            m_start = timeGetTime();
    }


  private:

    mutable boost::uint32_t m_start;
    mutable time_duration_type m_elapsed;

};

// Convenience typedef
typedef boost::timer<boost::timer_detail::tgt_clock> tgt_timer;

#endif // BOOST_WINDOWS

} // namespace boost

#endif // BOOST_TIMER_HPP
