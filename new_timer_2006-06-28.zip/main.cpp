#include <iostream>
#include <boost/timer_new.hpp>

using namespace std;

// Uncomment those at your needs
//#define TEST_SECOND_TIMER
//#define TEST_WIN32_TIMERS

inline void mysleep(int milliseconds)
{
	cout << "Sleeping for " << (milliseconds / 1000.0) << " seconds" << endl;
	#ifdef BOOST_WINDOWS
	Sleep(milliseconds);
	#else
	usleep(milliseconds * 1000);
	#endif
}

template <class timer>
inline void print_value(const timer& tmr, const double& expected)
{
	cout << "Current value: " << tmr.elapsed().seconds() << "." << tmr.elapsed().fractional_seconds() << " (~" << expected << " expected)" << endl;
}

template<class timer>
inline void run_test()
{
	cout << "Starting timer" << endl;
	timer tmr;
	mysleep(200);
	print_value(tmr, 0.2);
	mysleep(200);
	print_value(tmr, 0.4);

	cout << "Stopping timer" << endl;
	tmr.pause();
	print_value(tmr, 0.4);

	mysleep(1000);
	cout << "This last sleep should not be timed as the timer is stopped" << endl;
	print_value(tmr, 0.4);

	cout << "Resuming timer" << endl;
	tmr.resume();
	mysleep(200);
	print_value(tmr, 0.6);
	mysleep(200);
	print_value(tmr, 0.8);

	cout << "Restarting timer" << endl;
	tmr.reset();
	mysleep(200);
	print_value(tmr, 0.2);
	mysleep(1500);
	print_value(tmr, 1.7);
	mysleep(200);
	print_value(tmr, 1.9);
}

int main()
{
	cout << "[Testing with microsec timer]" << endl;
	run_test<boost::microsec_timer>();
	cout << "------------------------" << endl;

	#ifdef TEST_SECOND_TIMER
	cout << "[Testing with second timer]" << endl;
	run_test<boost::second_timer>();
	cout << "------------------------" << endl;
	#endif

	#ifdef TEST_WIN32_TIMERS
        #ifndef BOOST_WINDOWS
            #error Trying to test win32 timer on another platform than windows.
        #else
	        cout << "[Testing with QPC timer]" << endl;
	        run_test<boost::qpc_timer>();
	        cout << "------------------------" << endl;
	        cout << "[Testing with timeGetTime timer]" << endl;
	        run_test<boost::tgt_timer>();
	        cout << "------------------------" << endl;
        #endif
	#endif

	return 0;
}
