#include <map>
#include <string>
#include <iostream>

#include <boost/format.hpp>

#include "boost/timer.hpp"

using namespace std;

//#define BOOST_QPC_SET_AFFINITY

template<class timer> void run_test(const char* name);

int main()
{
    run_test<boost::microsec_timer>("microsec timer");
    //run_test<boost::second_timer>("second timer");
    run_test<boost::clock_timer>("clock timer");

    #ifndef BOOST_WINDOWS
        run_test<boost::gtod_timer>("gettimeofday() timer");
    #else
        run_test<boost::qpc_timer>("QueryPerformanceCounter() timer");
        run_test<boost::tgt_timer>("timeGetTime() timer");
        run_test<boost::gtc_timer>("GetTickCount() timer");
        run_test<boost::gstaft_timer>("GetSystemTimeAsFileTime() timer");
    #endif

    return 0;
}

inline void mssleep(int milliseconds)
{
	#ifdef BOOST_WINDOWS
	Sleep(milliseconds);
	#else
	usleep(milliseconds * 1000);
	#endif
}

struct checker
{
    explicit checker() : m_total(0.0)
    {
    }

    void set_total(const double& total)
    {
        m_total = total;
    }

    template <class timer>
    void check(const timer& tmr, const double& duration)
    {
        m_total += duration;
        mssleep(duration * 1000);

        typename timer::time_duration_type elapsed = tmr.elapsed();
        double value = elapsed.seconds() + elapsed.fractional_seconds() / static_cast<double>(elapsed.ticks_per_second());
        bool success = (m_total + 0.05 > value) && (m_total - 0.05 < value);
        cout << boost::format("time: %.3f  expected: %.3f  measured: %.3f  success: %s") % duration % m_total % value % (success ? "ok" : "error") << endl;
    }

    double m_total;
};

template<class timer>
inline void run_test(const char* name)
{
    timer tmr;
    checker chk;
    typename timer::time_duration_type elapsed, tmp;

    boost::basic_format<char> heading = boost::format(" Testing with %1% ") % name;
    int how_many = (59 - heading.str().size()) / 2;
    cout << string(how_many, '-') << heading << string(how_many, '-') << endl;

    cout << "[start]" << endl;
    tmr.restart();
    chk.set_total(0.0);
	chk.check(tmr, 0.128);
    chk.check(tmr, 0.128);
    chk.check(tmr, 0.444);

	cout << "[pause]" << endl;
	tmr.pause();
    tmp = tmr.elapsed();
    cout << "checking timer doesn't run while paused...";
    mssleep(300);
    cout << boost::format("%|14t|%1%") % (tmp == tmr.elapsed() ? "ok" : "error") << endl;

	cout << "[resume]" << endl;
	tmr.resume();
	chk.check(tmr, 0.67);
	chk.check(tmr, 0.33);

	cout << "[restart]" << endl;
	tmr.restart();
    chk.set_total(0.0);
	chk.check(tmr, 0.441);
    chk.check(tmr, 0.114);
    chk.check(tmr, 0.445);

    cout << endl;
}
